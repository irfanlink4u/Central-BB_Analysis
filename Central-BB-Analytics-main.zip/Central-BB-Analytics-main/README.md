# Central BB Analytics — React dashboard

Separate Supabase project: `yogjbkwurzjcuokcnhif` (Mumbai).

## Install and run (Windows CMD)

1. Extract the ZIP and open CMD inside the `central-bb-dashboard` folder.
2. Run `npm install`.
3. Copy `.env.example` to `.env` (`copy .env.example .env`).
4. Open `.env` and replace `PASTE_YOUR_PUBLISHABLE_KEY_HERE` with the **publishable** key from Supabase project Settings > API Keys. **Never put an `sb_secret_` or service_role key in `.env` or frontend code.**
5. In Supabase Dashboard > Authentication > Users, use **Add user** to create an email/password account for the dashboard. The user must belong to this specific project. Do not share credentials in chat.
6. Run `npm run dev` and open the local address shown (usually http://localhost:5173).
7. For production, run `npm run build`; deploy the `dist` folder or connect this repository to Vercel. Configure both `VITE_...` variables in Vercel project settings and build again.

## Data and permissions

- September 2026 site summary is loaded from `public.bb_site_summary` using Supabase Auth and read-only RLS policies for authenticated users.
- 5,889 sites are retrieved in 1,000-row pages; Supabase's default 1,000-row response limit does not truncate results.
- Filters and exports apply to the complete downloaded dataset.
- Incident drill-down is **not** included: `public.bb_incidents` currently has 0 rows. Incident counts come from site summaries.
- The 500-minute validity rule was applied by the Python engine before import; the UI does not recalculate or reinterpret it.
- `WOSD` measures duration of power alarms without Site Down, not necessarily the battery's true physical endurance.
- Sites without valid BB remain visible and show blank (—) metrics.
- WSD priority view is for investigation, not proof of battery failure.
- All existing Supabase projects remain unchanged.

## Troubleshooting

- Blank page: check `.env`, npm install, browser console.
- Sign-in error: create a user in this project's Authentication > Users.
- No rows: ensure you're signed in and the `bb_site_summary_authenticated_read` RLS policy exists.
- Never expose Supabase secret/service_role credentials in browser code or screenshots.
