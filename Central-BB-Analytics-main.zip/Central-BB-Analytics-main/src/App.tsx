import Papa from 'papaparse';

import {useEffect,useMemo,useState} from 'react';

import {createClient, type Session} from '@supabase/supabase-js';

import {Activity,BarChart3,BatteryCharging,Download,Filter,LogOut,Search,ShieldAlert,RefreshCw,ChevronLeft,ChevronRight,LockKeyhole,Eye,X,FileText} from 'lucide-react';

import {ResponsiveContainer,BarChart,Bar,XAxis,YAxis,Tooltip,CartesianGrid} from 'recharts';

const viteEnv=(import.meta as ImportMeta & {env:{VITE_SUPABASE_URL?:string;VITE_SUPABASE_PUBLISHABLE_KEY?:string}}).env;

const url=viteEnv.VITE_SUPABASE_URL;

const key=viteEnv.VITE_SUPABASE_PUBLISHABLE_KEY;

const supabase=url&&key?createClient(url,key):null;

type Site={site_id:string;sub_region:string|null;grid:string|null;revenue_category:string|null;dg_status:string|null;site_group:string|null;team_leader:string|null;valid_wsd_count:number|null;valid_wosd_count:number|null;excluded_count:number|null;review_count:number|null;all_incident_count:number|null;avg_wsd_min:number|null;max_wsd_min:number|null;avg_wosd_min:number|null;max_wosd_min:number|null;avg_bb_min:number|null;min_bb_min:number|null;max_bb_min:number|null;avg_toc_hours:number|null};

type Tab='overview'|'sites'|'low'|'degraded'|'anomalies'|'upload'|'avbcheck';

const TARGET_MIN=120;

type Assessment='Backup Satisfactory'|'Backup Below Standard'|'Technical Review Required';

type Incident={id:number;incident_key:string;site_id:string;pa_title:string|null;pa_occur:string|null;pa_clear:string|null;sd_title:string|null;sd_occur:string|null;bb_type:string|null;raw_backup_min:number|null;validated_backup_min:number|null;toc_hours:number|null;validation_status:string;exclusion_reason:string|null;pa_raw_duration_min?:number|null;post_clear_sd_occur?:string|null;post_clear_sd_gap_min?:number|null};

// Site assessment policy: any validated WSD or WOSD observation reaching 120 minutes

// establishes satisfactory demonstrated backup. Otherwise, observed validated

// backup below 120 minutes is low. No validated observation => review.

// WOSD is outage survival evidence, not a measurement of battery exhaustion.

function bestObservedBB(r:Site):number|null{

  const values:number[]=[];

  if(num(r.valid_wsd_count)>0 && r.max_wsd_min!=null) values.push(Number(r.max_wsd_min));

  if(num(r.valid_wosd_count)>0 && r.max_wosd_min!=null) values.push(Number(r.max_wosd_min));

  return values.length?Math.max(...values):null;

}

function assess(r:Site):Assessment{

  const best=bestObservedBB(r);

  if(best===null) return 'Technical Review Required';

  return best>=TARGET_MIN?'Backup Satisfactory':'Backup Below Standard';

}

const assessmentColor=(a:Assessment)=>a==='Backup Satisfactory'?'#087f51':a==='Backup Below Standard'?'#b42318':'#a15c00';

const assessmentBackground=(a:Assessment)=>a==='Backup Satisfactory'?'#e8f7ee':a==='Backup Below Standard'?'#fff0ed':'#fff4df';

const timestamp=(s:string|null|undefined)=>s?new Date(s).toLocaleString('en-GB',{dateStyle:'medium',timeStyle:'medium',hour12:false}):'—';



const fmt=(n:number|null|undefined,d=0)=>n==null?'—':Number(n).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});

const num=(n:number|null|undefined)=>Number(n??0);

const unique=(a:(string|null)[])=>[...new Set(a.filter((v):v is string=>Boolean(v)))].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));

const csvCell=(v:unknown)=>'"'+String(v??'').replace(/"/g,'""')+'"';

function exportCsv(rows:Site[],name:string){const cols:(keyof Site)[]=['site_id','sub_region','grid','revenue_category','dg_status','site_group','team_leader','avg_bb_min','min_bb_min','max_bb_min','avg_wsd_min','max_wsd_min','avg_wosd_min','max_wosd_min','avg_toc_hours','valid_wsd_count','valid_wosd_count','review_count','excluded_count','all_incident_count'];const data=[cols.join(','),...rows.map(r=>cols.map(k=>csvCell(r[k])).join(','))].join('\r\n');const blob=new Blob(['\uFEFF'+data],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();URL.revokeObjectURL(a.href)}

function App(){const[session,setSession]=useState<Session|null>(null),[authLoading,setAuthLoading]=useState(true),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[authError,setAuthError]=useState(''),[loginBusy,setLoginBusy]=useState(false);const[rows,setRows]=useState<Site[]>([]),[loading,setLoading]=useState(false),[error,setError]=useState(''),[tab,setTab]=useState<Tab>('overview'),[region,setRegion]=useState('All'),[grid,setGrid]=useState('All'),[dg,setDg]=useState('All'),[category,setCategory]=useState('All'),[search,setSearch]=useState(''),[page,setPage]=useState(1),[sort,setSort]=useState<'max_bb_min'|'avg_bb_min'|'max_wsd_min'>('max_bb_min');

 const[kpiDetail,setKpiDetail]=useState<'all'|'satisfactory'|'low'|'review'|null>(null),[customKpi,setCustomKpi]=useState<{title:string;siteIds:string[];missingIds?:string[]}|null>(null),[kpiSearch,setKpiSearch]=useState(''),[kpiPage,setKpiPage]=useState(1);const[selectedSite,setSelectedSite]=useState<Site|null>(null),[incidents,setIncidents]=useState<Incident[]>([]),[incidentLoading,setIncidentLoading]=useState(false),[incidentError,setIncidentError]=useState(''),[incidentTotal,setIncidentTotal]=useState(0),[incidentPage,setIncidentPage]=useState(1);

 const INCIDENT_PAGE_SIZE=30;

 const [reportMonth,setReportMonth]=useState('2026-09-01');

 const [avbIds,setAvbIds]=useState<string[]>([]);const [avbInput,setAvbInput]=useState('');const [avbError,setAvbError]=useState('');const [avbOnlyLow,setAvbOnlyLow]=useState(false);const [avbSearch,setAvbSearch]=useState('');const [avbPage,setAvbPage]=useState(1);

 const [uploadFiles,setUploadFiles]=useState<File[]>([]);

 const [uploadMode,setUploadMode]=useState<'initial'|'daily'>('initial');

 const [uploadBusy,setUploadBusy]=useState(false);

 const [uploadProgress,setUploadProgress]=useState('');

 const [uploadError,setUploadError]=useState('');

 const [uploadCounts,setUploadCounts]=useState({received:0,inserted:0,ignored:0});

 const monthLabel=reportMonth==='2026-09-01'?'September 2026':'October 2026';

 async function processUploads(){

  if(!supabase||!session||uploadFiles.length===0||uploadBusy)return;

  setUploadBusy(true);setUploadError('');setUploadCounts({received:0,inserted:0,ignored:0});

  const uploadId=crypto.randomUUID();let received=0,inserted=0,ignored=0;

  try{

   for(let fi=0;fi<uploadFiles.length;fi++){

    const file=uploadFiles[fi];let batchIndex=0;let batch:Record<string,string>[]=[];

    async function flush(){if(!batch.length)return;

     const payload={upload_id:uploadId,source_file:file.name,batch_index:batchIndex++,rows:batch};batch=[];

     let lastError='';

     for(let attempt=1;attempt<=3;attempt++){

      const {data,error}=await supabase!.functions.invoke('bb-upload-batch',{body:payload});

      if(!error&&!data?.error){received+=Number(data.received??0);inserted+=Number(data.inserted??0);ignored+=Number(data.ignored??0);setUploadCounts({received,inserted,ignored});setUploadProgress(`File ${fi+1}/${uploadFiles.length}: ${file.name} — ${received.toLocaleString()} records sent`);return;}

      lastError=String(data?.error??error?.message??'Upload failed');

      await new Promise(r=>setTimeout(r,attempt*900));

     }

     throw new Error(`Batch ${payload.batch_index} failed: ${lastError}`);

    }

    await new Promise<void>((resolve,reject)=>{

     let failed=false;

     Papa.parse<Record<string,string>>(file,{header:true,skipEmptyLines:true,worker:false,

      step:(result,parser)=>{if(failed)return;

       const r=result.data;

       batch.push({site_id:r['Site']??'',alarm_title:r['Alarm title']??'',occur_time:r['Occur Time']??'',clear_time:r['Clear Time']??'',alarm_id:r['Alarm ID']??'',grid:r['Grid']??'',sub_region:r['SubRegion']??''});

       if(batch.length>=400){parser.pause();void flush().then(()=>parser.resume()).catch(e=>{failed=true;parser.abort();reject(e)});}

      },

      complete:()=>{if(!failed)void flush().then(resolve).catch(reject);},

      error:(e)=>{failed=true;reject(e)}

     });

    });

   }

   setUploadProgress(`Upload completed: ${received.toLocaleString()} source records processed; ${inserted.toLocaleString()} new alarms stored. Backup calculations are pending.`);

  }catch(e){setUploadError(e instanceof Error?e.message:String(e));setUploadProgress('Upload stopped. Previously completed batches remain stored; duplicates will be ignored on retry.');}

  finally{setUploadBusy(false)}

 }



 async function openEvidence(r:Site){setSelectedSite(r);setIncidents([]);setIncidentTotal(0);setIncidentPage(1);await loadEvidence(r.site_id,1)}

 async function loadEvidence(siteId:string,p:number){if(!supabase)return;setIncidentLoading(true);setIncidentError('');try{const from=(p-1)*INCIDENT_PAGE_SIZE;const {data,error,count}=await supabase.from('bb_incidents').select('id,incident_key,site_id,pa_title,pa_occur,pa_clear,sd_title,sd_occur,bb_type,raw_backup_min,validated_backup_min,toc_hours,validation_status,exclusion_reason,pa_raw_duration_min,post_clear_sd_occur,post_clear_sd_gap_min',{count:'exact'}).eq('reporting_month',reportMonth).eq('site_id',siteId).order('pa_occur',{ascending:false}).range(from,from+INCIDENT_PAGE_SIZE-1);if(error)throw error;setIncidents((data??[]) as Incident[]);setIncidentTotal(count??0);setIncidentPage(p)}catch(e){setIncidentError(e instanceof Error?e.message:String(e))}finally{setIncidentLoading(false)}}



useEffect(()=>{if(!supabase){setAuthLoading(false);return}supabase.auth.getSession().then(({data})=>{setSession(data.session);setAuthLoading(false)});const{data:{subscription}}=supabase.auth.onAuthStateChange((_event,s)=>setSession(s));return()=>subscription.unsubscribe()},[]);

async function load(){if(!supabase||!session)return;setLoading(true);setError('');try{const all:Site[]=[];for(let from=0;;from+=1000){const{data,error}=await supabase.from('bb_site_summary').select('site_id,sub_region,grid,revenue_category,dg_status,site_group,team_leader,valid_wsd_count,valid_wosd_count,excluded_count,review_count,all_incident_count,avg_wsd_min,max_wsd_min,avg_wosd_min,max_wosd_min,avg_bb_min,min_bb_min,max_bb_min,avg_toc_hours').eq('reporting_month',reportMonth).order('site_id',{ascending:true}).range(from,from+999);if(error)throw error;all.push(...(data??[]) as Site[]);if(!data||data.length<1000)break;}setRows(all)}catch(e){setError(e instanceof Error?e.message:String(e))}finally{setLoading(false)}}

useEffect(()=>{if(session)void load();else setRows([])},[session,reportMonth]);

const regions=useMemo(()=>unique(rows.map(r=>r.sub_region)),[rows]);const regionRows=useMemo(()=>rows.filter(r=>region==='All'||r.sub_region===region),[rows,region]);const grids=useMemo(()=>unique(regionRows.map(r=>r.grid)),[regionRows]);const categories=useMemo(()=>unique(rows.map(r=>r.revenue_category)),[rows]);const dgStatuses=useMemo(()=>unique(rows.map(r=>r.dg_status)),[rows]);

const filtered=useMemo(()=>rows.filter(r=>(region==='All'||r.sub_region===region)&&(grid==='All'||r.grid===grid)&&(dg==='All'||r.dg_status===dg)&&(category==='All'||r.revenue_category===category)&&(!search||[r.site_id,r.team_leader,r.grid].some(v=>String(v??'').toLowerCase().includes(search.toLowerCase())))),[rows,region,grid,dg,category,search]);

const assessments=useMemo(()=>({satisfactory:filtered.filter(r=>assess(r)==='Backup Satisfactory').length,low:filtered.filter(r=>assess(r)==='Backup Below Standard').length,review:filtered.filter(r=>assess(r)==='Technical Review Required').length}),[filtered]);

 const kpiRows=useMemo(()=>{const base=customKpi?rows.filter(r=>customKpi.siteIds.includes(r.site_id)):filtered.filter(r=>kpiDetail==='all'||(kpiDetail==='satisfactory'&&assess(r)==='Backup Satisfactory')||(kpiDetail==='low'&&assess(r)==='Backup Below Standard')||(kpiDetail==='review'&&assess(r)==='Technical Review Required'));return base.filter(r=>!kpiSearch||[r.site_id,r.grid,r.sub_region,r.team_leader,r.revenue_category,r.dg_status].some(v=>String(v??'').toLowerCase().includes(kpiSearch.toLowerCase()))).sort((a,b)=>a.site_id.localeCompare(b.site_id,undefined,{numeric:true}))},[filtered,rows,kpiDetail,customKpi,kpiSearch]);

 const openKpi=(title:string,sites:Site[],missingIds:string[]=[] )=>{setKpiDetail(null);setCustomKpi({title,siteIds:[...new Set(sites.map(r=>r.site_id))],missingIds});setKpiSearch('');setKpiPage(1)};

 const closeKpi=()=>{setKpiDetail(null);setCustomKpi(null)};

 const kpiCard=(title:string,value:string|number,color:string,sites:Site[],detail:string,missingIds:string[]=[])=> <button type="button" key={title} className="kpi" onClick={()=>openKpi(title,sites,missingIds)} style={{borderTop:`5px solid ${color}`,textAlign:'left',cursor:'pointer',background:'#fff',color:'#183343',width:'100%'}} aria-label={`Review sites: ${title}`}><span>{title}</span><strong>{typeof value==='number'?fmt(value):value}</strong><small>{detail}</small><span style={{display:'block',fontSize:12,color,fontWeight:800,marginTop:12}}>View sites and calculations →</span></button>;

 const kpiPageCount=Math.max(1,Math.ceil(kpiRows.length/25));

 useEffect(()=>{setKpiPage(1);setKpiSearch('')},[kpiDetail,customKpi,reportMonth,region,grid,dg,category,search]);

 const avbLookup=useMemo(()=>new Map(rows.map(r=>[r.site_id.trim(),r])),[rows]);

 const avbResults=useMemo(()=>avbIds.map(id=>({id,site:avbLookup.get(id)??null})).filter(x=>(!avbOnlyLow||(x.site&&assess(x.site)==='Backup Below Standard'))&&(!avbSearch||x.id.toLowerCase().includes(avbSearch.toLowerCase())||String(x.site?.grid??'').toLowerCase().includes(avbSearch.toLowerCase()))),[avbIds,avbLookup,avbOnlyLow,avbSearch]);

 const avbStats=useMemo(()=>({matched:avbIds.filter(id=>avbLookup.has(id)).length,low:avbIds.filter(id=>{const r=avbLookup.get(id);return r&&assess(r)==='Backup Below Standard'}).length,ok:avbIds.filter(id=>{const r=avbLookup.get(id);return r&&assess(r)==='Backup Satisfactory'}).length,review:avbIds.filter(id=>{const r=avbLookup.get(id);return r&&assess(r)==='Technical Review Required'}).length}),[avbIds,avbLookup]);

 function importAvbIds(text:string){const parsed=Papa.parse<string[]>(text,{skipEmptyLines:true});const values=parsed.data.flatMap(row=>row).flatMap(v=>String(v??'').split(/[\s;|]+/)).map(v=>v.trim().replace(/^['"]|['"]$/g,'')).filter(v=>/^[0-9]{3,8}$/.test(v));const ids=[...new Set(values)];if(!ids.length){setAvbError('No numeric Site IDs detected. Upload a CSV with a Site ID column or paste site IDs.');return;}setAvbIds(ids);setAvbError('');setAvbPage(1)}

 async function importAvbFile(file:File|undefined){if(!file)return;if(!/\.(csv|txt)$/i.test(file.name)){setAvbError('Please save your Excel site list as CSV first, then upload it here.');return;}try{const content=await file.text();if(/\.txt$/i.test(file.name)){importAvbIds(content);return;}const parsed=Papa.parse<Record<string,string>>(content,{header:true,skipEmptyLines:true});const headers=parsed.meta.fields??[];const idHeader=headers.find(h=>/^(site\s*(id|name)?|site\s*id\s*name|siteid|site_id)$/i.test(h.trim()))??headers.find(h=>/site/i.test(h));if(!idHeader){setAvbError('CSV must contain a Site ID column.');return;}const ids=[...new Set(parsed.data.map(r=>String(r[idHeader]??'').trim()).filter(v=>/^[0-9]{3,8}$/.test(v)))];if(!ids.length){setAvbError('No valid Site IDs in the selected CSV column.');return;}setAvbIds(ids);setAvbPage(1);setAvbError('')}catch(e){setAvbError(String(e))}}

 function exportAvbResults(){const cols=['Site ID','Match Status','Assessment','Sub-region','Grid','GTL','Revenue Class','DG Status','Best WSD/WOSD (min)','Average BB','Maximum BB','Average WSD','Maximum WSD','Average WOSD','Maximum WOSD','WSD Events','WOSD Events','Review','Excluded'];const body=avbResults.map(({id,site:r})=>[id,r?'Matched':'Not found',r?assess(r):'Not found',r?.sub_region,r?.grid,r?.team_leader,r?.revenue_category,r?.dg_status,r?bestObservedBB(r):null,r?.avg_bb_min,r?.max_bb_min,r?.avg_wsd_min,r?.max_wsd_min,r?.avg_wosd_min,r?.max_wosd_min,r?.valid_wsd_count,r?.valid_wosd_count,r?.review_count,r?.excluded_count]);const csv=[cols,...body].map(row=>row.map(csvCell).join(',')).join('\r\n');const blob=new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`Cell_AVB_BB_Check_${reportMonth.slice(0,7)}.csv`;a.click();URL.revokeObjectURL(a.href)}

 const lowSites=useMemo(()=>filtered.filter(r=>assess(r)==='Backup Below Standard'),[filtered]);

 const lowSummary=useMemo(()=>({

  sites:lowSites.length,

  events:lowSites.reduce((n,r)=>n+num(r.valid_wsd_count)+num(r.valid_wosd_count),0),

  under60:lowSites.filter(r=>{const best=bestObservedBB(r);return best!==null&&best<60}).length,

  avgObserved:(()=>{const measured=lowSites.map(bestObservedBB).filter((v):v is number=>v!==null);return measured.length?measured.reduce((n,v)=>n+v,0)/measured.length:null})()

 }),[lowSites]);

 const totals=useMemo(()=>filtered.reduce((a,r)=>({sites:a.sites+1,valid:a.valid+num(r.valid_wsd_count)+num(r.valid_wosd_count),wsd:a.wsd+num(r.valid_wsd_count),wosd:a.wosd+num(r.valid_wosd_count),excluded:a.excluded+num(r.excluded_count),review:a.review+num(r.review_count),measured:a.measured+(r.max_bb_min==null?0:1)}),{sites:0,valid:0,wsd:0,wosd:0,excluded:0,review:0,measured:0}),[filtered]);

const grouped=useMemo(()=>{const m=new Map<string,{name:string;sites:number;wsd:number;review:number;excluded:number;sumMax:number;nMax:number}>();for(const r of filtered){const name=region==='All'?r.sub_region||'Unknown':r.grid||'Unknown';const a=m.get(name)||{name,sites:0,wsd:0,review:0,excluded:0,sumMax:0,nMax:0};a.sites++;a.wsd+=num(r.valid_wsd_count);a.review+=num(r.review_count);a.excluded+=num(r.excluded_count);if(r.max_bb_min!=null){a.sumMax+=num(r.max_bb_min);a.nMax++}m.set(name,a)}return[...m.values()].map(a=>({...a,avgMax:a.nMax?a.sumMax/a.nMax:0})).sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true}))},[filtered,region]);

const ordered=useMemo(()=>[...filtered].filter(r=>tab!=='low'||assess(r)==='Backup Below Standard').sort((a,b)=>{if(tab==='degraded'){const aa=assess(a)==='Backup Below Standard'?0:1,bb=assess(b)==='Backup Below Standard'?0:1;if(aa!==bb)return aa-bb;return num(a.avg_wsd_min||a.max_wsd_min)-num(b.avg_wsd_min||b.max_wsd_min)}if(tab==='anomalies')return num(b.review_count)+num(b.excluded_count)-num(a.review_count)-num(a.excluded_count);const av=a[sort],bv=b[sort];if(av==null)return 1;if(bv==null)return -1;return Number(bv)-Number(av)}),[filtered,tab,sort]);

const pages=Math.max(1,Math.ceil(ordered.length/25));const visible=ordered.slice((Math.min(page,pages)-1)*25,Math.min(page,pages)*25);useEffect(()=>setPage(1),[region,grid,dg,category,search,tab,sort]);

async function signIn(e:React.FormEvent){e.preventDefault();if(!supabase)return;setLoginBusy(true);setAuthError('');const{error}=await supabase.auth.signInWithPassword({email,password});if(error)setAuthError(error.message);setLoginBusy(false)}

if(!supabase)return <div className="login"><div className="login-card"><h1>Central BB Analytics</h1><p>Missing Supabase configuration. Copy <code>.env.example</code> to <code>.env</code> and set the project publishable key.</p></div></div>;

if(authLoading)return <div className="center">Checking authentication…</div>;

if(!session)return <div className="login"><form className="login-card" onSubmit={signIn}><div className="brand-icon"><BatteryCharging/></div><h1>Central BB Analytics</h1><p>Secure field operations management dashboard</p><label>Email address<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@company.com"/></label><label>Password<input type="password" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="Your password"/></label>{authError&&<div className="error">{authError}</div>}<button className="primary" disabled={loginBusy}>{loginBusy?'Signing in…':'Sign in securely'}</button><small><LockKeyhole size={13}/> Access requires a Supabase Auth user created by your project administrator.</small></form></div>;

return <div className="app"><aside className="sidebar"><div className="logo"><span className="logo-mark"><BatteryCharging/></span><span><strong>CENTRAL BB</strong><small>ANALYTICS · ZONG 5G</small></span></div><div className="nav-title">MANAGEMENT</div>{([['overview','Overview',BarChart3],['sites','Site Performance',BatteryCharging],['low','Low Battery Backup',ShieldAlert],['degraded','WSD Priorities',Activity],['anomalies','Anomalies',ShieldAlert],['upload','Alarm Upload',FileText],['avbcheck','Cell AVB <98% · BB Check',Search]] as const).map(([id,label,Icon])=><button key={id} className={'nav '+(tab===id?'active':'')} onClick={()=>setTab(id)}><Icon size={18}/>{label}</button>)}<div className="sidebar-bottom"><span>{monthLabel}</span><small>V3.1 · All Central Regions</small><button className="logout" onClick={()=>void supabase.auth.signOut()}><LogOut size={16}/> Sign out</button></div></aside><main className="main"><header className="topbar"><div><div className="eyebrow">FIELD OPERATIONS / POWER RESILIENCE</div><h1>Central Battery Backup</h1><p>Complete Central · {monthLabel} · {reportMonth==='2026-09-01'?'Verified Incident Analytics':'Provisional Analytics · Not Validated'}</p></div><div className="actions"><button className="outline" onClick={()=>void load()} disabled={loading}><RefreshCw size={16}/> Refresh</button><button className="primary" onClick={()=>exportCsv(filtered,`Central_BB_${reportMonth.slice(0,7)}.csv`)} disabled={!filtered.length}><Download size={16}/> Export CSV</button></div></header>

<section className="filters"><label>Reporting Month<select value={reportMonth} onChange={e=>{setReportMonth(e.target.value);setSelectedSite(null);setRegion('All');setGrid('All')}}><option value="2026-09-01">September 2026</option><option value="2026-10-01">October 2026</option></select></label><div className="filter-title"><Filter size={16}/> FILTERS</div><label>Sub-region<select value={region} onChange={e=>{setRegion(e.target.value);setGrid('All')}}><option value="All">All Central</option>{regions.map(x=><option key={x}>{x}</option>)}</select></label><label>Grid<select value={grid} onChange={e=>setGrid(e.target.value)}><option value="All">All Grids</option>{grids.map(x=><option key={x}>{x}</option>)}</select></label><label>DG Status<select value={dg} onChange={e=>setDg(e.target.value)}><option value="All">All DG Statuses</option>{dgStatuses.map(x=><option key={x}>{x}</option>)}</select></label><label>Revenue Class<select value={category} onChange={e=>setCategory(e.target.value)}><option value="All">All Categories</option>{categories.map(x=><option key={x}>{x}</option>)}</select></label><label className="search-label">Site / GTL / Grid<div className="search"><Search size={15}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search site ID..."/></div></label></section>

{error&&<div className="error">Database error: {error}</div>}{loading&&<div className="notice">Loading {monthLabel} site records…</div>}{!loading&&rows.length===0&&!error&&<div className="notice">No site records are visible. Check your authenticated user's access and RLS policy.</div>}

{tab==='avbcheck'&&<section className="panel" style={{padding:24,marginBottom:20}}><h2>Cell AVB Below 98% — Battery Backup Cross-Check</h2><p>Upload your list of degraded Cell AVB sites. The comparison uses the selected reporting month's site summaries, including validated WSD and WOSD. Uploaded IDs stay in this browser session and are not added to Supabase.</p>

 <div style={{display:'flex',gap:16,flexWrap:'wrap',alignItems:'flex-start',margin:'16px 0'}}><label style={{fontWeight:700}}>Upload site list (.csv / .txt)<input type="file" accept=".csv,.txt,text/csv,text/plain" onChange={e=>void importAvbFile(e.target.files?.[0])} style={{display:'block',marginTop:8}}/></label><label style={{fontWeight:700}}>Or paste Site IDs<textarea value={avbInput} onChange={e=>setAvbInput(e.target.value)} placeholder={'Site ID\n4961\n7613\n6601'} rows={4} style={{display:'block',minWidth:280,marginTop:8,padding:10,border:'1px solid #cbdde5',borderRadius:9}}/></label><button className="primary" style={{alignSelf:'center'}} onClick={()=>importAvbIds(avbInput)}>Check Pasted Sites</button><button className="outline" style={{alignSelf:'center'}} onClick={()=>{setAvbIds([]);setAvbInput('');setAvbError('')}}>Clear List</button></div>

 {avbError&&<div className="error">{avbError}</div>}

 {avbIds.length>0&&<><div className="kpis" style={{display:'grid',gridTemplateColumns:'repeat(4,minmax(0,1fr))',gap:14}}>

 {kpiCard('Uploaded Sites',avbIds.length,'#2563eb',avbIds.map(id=>avbLookup.get(id)).filter((r):r is Site=>Boolean(r)),'Includes unmatched IDs',avbIds.filter(id=>!avbLookup.has(id)))}

 {kpiCard('Matched in BB',avbStats.matched,'#0a9363',avbIds.map(id=>avbLookup.get(id)).filter((r):r is Site=>Boolean(r)),'View matched site calculations')}

 {kpiCard('Low Backup',avbStats.low,'#d44b3e',avbIds.map(id=>avbLookup.get(id)).filter((r):r is Site=>r !== undefined && assess(r)==='Backup Below Standard'),'Below 120 min')}

 {kpiCard('Satisfactory / Review',`${avbStats.ok} / ${avbStats.review}`,'#e6a11b',avbIds.map(id=>avbLookup.get(id)).filter((r):r is Site=>r !== undefined && assess(r)!=='Backup Below Standard'),'View both groups')}

 </div>

 <div style={{display:'flex',gap:12,flexWrap:'wrap',alignItems:'center',margin:'18px 0'}}><label><input type="checkbox" checked={avbOnlyLow} onChange={e=>{setAvbOnlyLow(e.target.checked);setAvbPage(1)}}/> Show low backup only</label><input value={avbSearch} onChange={e=>{setAvbSearch(e.target.value);setAvbPage(1)}} placeholder="Search Site ID or Grid" style={{padding:10,border:'1px solid #d0dfe7',borderRadius:8}}/><button className="outline" onClick={exportAvbResults}><Download size={15}/> Export Comparison CSV</button></div>

 <div style={{overflowX:'auto'}}><table><thead><tr>{['Site ID','Match','BB Assessment','Grid','GTL','Revenue Class','DG','Best WSD/WOSD','Avg BB','Max BB','Avg WSD','Max WSD','Avg WOSD','Max WOSD','WSD','WOSD','Review','Evidence'].map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{avbResults.slice((avbPage-1)*25,avbPage*25).map(({id,site:r})=><tr key={id}><td className="site">{id}</td><td>{r?'Matched':'Not found'}</td><td>{r?assess(r):'Not found'}</td><td>{r?.grid??'—'}</td><td>{r?.team_leader??'—'}</td><td>{r?.revenue_category??'—'}</td><td>{r?.dg_status??'—'}</td><td>{r?fmt(bestObservedBB(r),1):'—'}</td><td>{fmt(r?.avg_bb_min,1)}</td><td>{fmt(r?.max_bb_min,1)}</td><td>{fmt(r?.avg_wsd_min,1)}</td><td>{fmt(r?.max_wsd_min,1)}</td><td>{fmt(r?.avg_wosd_min,1)}</td><td>{fmt(r?.max_wosd_min,1)}</td><td>{fmt(r?.valid_wsd_count)}</td><td>{fmt(r?.valid_wosd_count)}</td><td>{fmt(r?.review_count)}</td><td>{r&&<button className="outline" onClick={()=>void openEvidence(r)}><Eye size={14}/> View Calculation</button>}</td></tr>)}</tbody></table></div><div className="table-footer"><span>{fmt(avbResults.length)} sites · Page {avbPage} of {Math.max(1,Math.ceil(avbResults.length/25))}</span><div><button disabled={avbPage<=1} onClick={()=>setAvbPage(n=>n-1)}><ChevronLeft size={16}/></button><button disabled={avbPage*25>=avbResults.length} onClick={()=>setAvbPage(n=>n+1)}><ChevronRight size={16}/></button></div></div>

 <div className="notice">Unmatched sites are listed explicitly. October results remain provisional until validated; blank measurements do not mean zero backup.</div></>}</section>}

 {tab==='upload'&&<section className="kpis">{kpiCard('Site Summaries Available',filtered.length,'#2563eb',filtered,'View existing site calculations')}{kpiCard('Sites With Evidence',filtered.filter(r=>num(r.all_incident_count)>0).length,'#0a9363',filtered.filter(r=>num(r.all_incident_count)>0),'Existing incident evidence')}</section>}{tab==='upload'&&<section className="panel" style={{padding:24,marginBottom:20}}><h2>October Alarm Upload</h2><p>Initial upload: all seven NOC CSV files covering 01–16 October 2026. Later: previous-day closed alarms only.</p><div style={{display:'flex',gap:16,flexWrap:'wrap',alignItems:'center',margin:'16px 0'}}><label>Upload type<select value={uploadMode} onChange={e=>setUploadMode(e.target.value as 'initial'|'daily')}><option value="initial">Initial historical upload</option><option value="daily">Daily incremental upload</option></select></label><label>Choose NOC CSV files<input type="file" accept=".csv,text/csv" multiple onChange={e=>setUploadFiles(Array.from(e.target.files??[]))}/></label></div><p><strong>{uploadFiles.length}</strong> selected file(s) · {fmt(uploadFiles.reduce((n,f)=>n+f.size,0)/1024/1024,1)} MB</p>{uploadFiles.length>0&&<div style={{maxHeight:180,overflow:'auto',background:'#f4f8f8',padding:12,borderRadius:8}}>{uploadFiles.map(f=><div key={f.name}>{f.name} — {fmt(f.size/1024/1024,1)} MB</div>)}</div>}<div className="notice" style={{marginTop:16}}>Secure raw-alarm upload is active. Duplicate records are ignored. <strong>Backup calculation and October site summaries are not yet activated.</strong> This step stores the original evidence only.</div><button className="primary" disabled={uploadBusy||uploadFiles.length===0} onClick={()=>void processUploads()}>{uploadBusy?'Uploading alarm records…':'Upload Alarm Evidence'}</button>{uploadProgress&&<div className="notice" style={{marginTop:12}}>{uploadProgress}</div>}{uploadError&&<div className="error" style={{marginTop:12}}>Upload error: {uploadError}</div>}{uploadCounts.received>0&&<p>Processed: {fmt(uploadCounts.received)} · Newly stored: {fmt(uploadCounts.inserted)} · Invalid/ignored: {fmt(uploadCounts.ignored)}</p>}</section>}{tab==='overview'&&<section className="kpis" style={{display:'grid',gridTemplateColumns:'repeat(4,minmax(0,1fr))',gap:16}}>

 {([

 ['all','Total Sites Reviewed',filtered.length,'#2563eb','All sites in current selection'],

 ['satisfactory','Backup Satisfactory',assessments.satisfactory,'#0b9360','Validated WSD/WOSD reaches ≥120 min'],

 ['low','Backup Below Standard',assessments.low,'#d44c3a','No validated WSD/WOSD reaches 120 min'],

 ['review','Technical Review Required',assessments.review,'#e3a124','Insufficient evidence for assessment']

 ] as const).map(([id,title,count,color,description])=><button type="button" key={id} onClick={()=>setKpiDetail(id)} aria-label={`Review ${title} sites`} style={{background:'#fff',border:'1px solid #dce6eb',borderTop:`5px solid ${color}`,borderRadius:18,padding:'22px 20px',textAlign:'left',cursor:'pointer',boxShadow:'0 5px 20px #20394b0a',color:'#183343',minWidth:0}}>

 <span style={{display:'block',fontSize:14,fontWeight:750,color:'#61788a',minHeight:38}}>{title}</span>

 <strong style={{display:'block',fontSize:36,lineHeight:1.2,margin:'5px 0 14px'}}>{fmt(count)}</strong>

 <small style={{display:'block',fontSize:12,color:'#71899b',minHeight:32}}>{description}</small>

 <span style={{display:'block',fontSize:12,color:color,fontWeight:800,marginTop:12}}>View sites →</span>

 </button>)}</section>}{tab==='overview'&&<section className="kpis">

 {kpiCard('Sites in Selection',totals.sites,'#0a9363',filtered,`${fmt(totals.measured)} with valid backup`)}

 {kpiCard('Valid BB Incidents',totals.valid,'#2497cc',filtered.filter(r=>num(r.valid_wsd_count)+num(r.valid_wosd_count)>0),`${fmt(totals.wsd)} WSD · ${fmt(totals.wosd)} WOSD`)}

 {kpiCard('Review Required',totals.review,'#e6a11b',filtered.filter(r=>num(r.review_count)>0),'Sites with review incidents')}

 {kpiCard('Excluded Incidents',totals.excluded,'#687e8c',filtered.filter(r=>num(r.excluded_count)>0),'Sites with excluded incidents')}

 </section>}

{tab==='low'&&<section className="kpis" style={{display:'grid',gridTemplateColumns:'repeat(4,minmax(0,1fr))',gap:16}}>

 {kpiCard('Low Backup Sites',lowSummary.sites,'#dc4b3e',lowSites,'Best WSD/WOSD below 120 min')}

 {kpiCard('Valid BB Incidents',lowSummary.events,'#2563eb',lowSites.filter(r=>num(r.valid_wsd_count)+num(r.valid_wosd_count)>0),'Events on low-backup sites')}

 {kpiCard('Mean Best BB',lowSummary.avgObserved===null?'—':fmt(lowSummary.avgObserved,1)+' min','#0b9360',lowSites.filter(r=>bestObservedBB(r)!==null),'Average of best observations')}

 {kpiCard('Critical Below 60 min',lowSummary.under60,'#e59b16',lowSites.filter(r=>{const n=bestObservedBB(r);return n!==null&&n<60}),'Sites below 60 min')}

 </section>}

 {tab==='sites'&&<section className="kpis">

 {kpiCard('All Sites',filtered.length,'#2563eb',filtered,'Current selection')}

 {kpiCard('Backup Satisfactory',assessments.satisfactory,'#0a9363',filtered.filter(r=>assess(r)==='Backup Satisfactory'),'Validated 120+ min')}

 {kpiCard('Low Backup',assessments.low,'#d44b3e',filtered.filter(r=>assess(r)==='Backup Below Standard'),'Below 120 min')}

 {kpiCard('Technical Review',assessments.review,'#e6a11b',filtered.filter(r=>assess(r)==='Technical Review Required'),'Insufficient evidence')}

 </section>}

 {tab==='degraded'&&<section className="kpis">

 {kpiCard('WSD Sites',filtered.filter(r=>num(r.valid_wsd_count)>0).length,'#2563eb',filtered.filter(r=>num(r.valid_wsd_count)>0),'Sites with validated WSD')}

 {kpiCard('Low Backup WSD',filtered.filter(r=>num(r.valid_wsd_count)>0&&assess(r)==='Backup Below Standard').length,'#d44b3e',filtered.filter(r=>num(r.valid_wsd_count)>0&&assess(r)==='Backup Below Standard'),'WSD sites below target')}

 {kpiCard('WSD 120+ Min',filtered.filter(r=>num(r.valid_wsd_count)>0&&assess(r)==='Backup Satisfactory').length,'#0a9363',filtered.filter(r=>num(r.valid_wsd_count)>0&&assess(r)==='Backup Satisfactory'),'WSD sites meeting target')}

 {kpiCard('WSD Technical Review',filtered.filter(r=>num(r.valid_wsd_count)>0&&assess(r)==='Technical Review Required').length,'#e6a11b',filtered.filter(r=>num(r.valid_wsd_count)>0&&assess(r)==='Technical Review Required'),'Needs assessment')}

 </section>}

 {tab==='anomalies'&&<section className="kpis">

 {kpiCard('Sites With Anomalies',filtered.filter(r=>num(r.review_count)+num(r.excluded_count)>0).length,'#2563eb',filtered.filter(r=>num(r.review_count)+num(r.excluded_count)>0),'Review or excluded evidence')}

 {kpiCard('Review Required',totals.review,'#e6a11b',filtered.filter(r=>num(r.review_count)>0),'Review incidents')}

 {kpiCard('Excluded Incidents',totals.excluded,'#d44b3e',filtered.filter(r=>num(r.excluded_count)>0),'Above validation limits')}

 {kpiCard('No Anomalies',filtered.filter(r=>num(r.review_count)+num(r.excluded_count)===0).length,'#0a9363',filtered.filter(r=>num(r.review_count)+num(r.excluded_count)===0),'No recorded anomalies')}

 </section>}

{tab==='overview'&&<section className="charts"><div className="panel"><h2>{region==='All'?'Sub-region':'Grid'} comparison</h2><p>Sites by operational area</p><div className="chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={grouped}><CartesianGrid strokeDasharray="3 3" vertical={false}/><XAxis dataKey="name" tick={{fontSize:11}} interval={0} angle={grouped.length>12?-35:0} textAnchor={grouped.length>12?'end':'middle'} height={grouped.length>12?80:30}/><YAxis tick={{fontSize:11}}/><Tooltip/><Bar dataKey="sites" name="Sites" fill="#17a45b" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div></div><div className="panel"><h2>Mean of site Maximum BB</h2><p>Average of individual site maxima · minutes · not physical capacity</p><div className="chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={grouped}><CartesianGrid strokeDasharray="3 3" vertical={false}/><XAxis dataKey="name" tick={{fontSize:11}} interval={0} angle={grouped.length>12?-35:0} textAnchor={grouped.length>12?'end':'middle'} height={grouped.length>12?80:30}/><YAxis tick={{fontSize:11}}/><Tooltip formatter={(v:number)=>fmt(v,1)}/><Bar dataKey="avgMax" name="Mean Max BB (min)" fill="#2497cc" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div></div></section>}

{tab==='low'&&reportMonth==='2026-10-01'&&<div className="notice">October backup results are provisional. Low-backup classification requires validated WSD evidence; zero displayed sites does not mean zero low-backup sites.</div>}{tab!=='upload'&&tab!=='avbcheck'&&<section className="panel table-panel"><div className="table-heading"><div><h2>{tab==='overview'?'Site-wise Battery Backup':tab==='sites'?'All Site Performance':tab==='degraded'?'WSD Investigation Priorities':tab==='low'?'Low Battery Backup — WSD/WOSD Below 120 Minutes':'Review & Exclusion Ranking'}</h2><p>{tab==='low'?'Best validated WSD/WOSD below 120 minutes, with no qualifying observation reaching 120 minutes. View Calculation provides supporting evidence. Provisional October records remain unclassified.':tab==='degraded'?'Lowest observed maximum WSD first; investigate alarm alignment before labeling battery failure.':tab==='anomalies'?'Sorted by combined review and excluded incident counts.':'Maximum and average BB are shown together. Blank values mean no valid measurement.'}</p></div><div className="table-actions">{tab!=='degraded'&&tab!=='anomalies'&&<label>Sort <select value={sort} onChange={e=>setSort(e.target.value as typeof sort)}><option value="max_bb_min">Maximum BB</option><option value="avg_bb_min">Average BB</option><option value="max_wsd_min">Maximum WSD</option></select></label>}<button className="outline" onClick={()=>exportCsv(ordered,tab==='low'?`Central_BB_Low_Backup_${reportMonth.slice(0,7)}.csv`:'Central_BB_Filtered_Sites.csv')}><Download size={15}/> Export</button></div></div><div className="table-scroll"><table><thead><tr><th>Site ID</th><th>Assessment</th><th>Evidence</th><th>Sub-region</th><th>Grid</th><th>Class</th><th>DG</th><th>Avg BB</th><th>Max BB</th><th>Avg WSD</th><th>Max WSD</th><th>Avg WOSD</th><th>Max WOSD</th><th>WSD Events</th><th>WOSD Events</th><th>Review</th><th>Excluded</th></tr></thead><tbody>{visible.map(r=><tr key={r.site_id}><td className="site">{r.site_id}</td><td><span style={{display:'inline-block',whiteSpace:'nowrap',padding:'5px 9px',borderRadius:16,fontWeight:700,fontSize:12,color:assessmentColor(assess(r)),background:assessmentBackground(assess(r))}}>{assess(r)}</span></td><td><button type="button" className="outline" onClick={()=>void openEvidence(r)} style={{display:'inline-flex',alignItems:'center',gap:6,whiteSpace:'nowrap',padding:'7px 10px'}}><Eye size={15}/> View Calculation</button></td><td>{r.sub_region||'—'}</td><td>{r.grid||'—'}</td><td>{r.revenue_category||'—'}</td><td>{r.dg_status||'—'}</td><td>{fmt(r.avg_bb_min,1)}</td><td className="highlight">{fmt(r.max_bb_min,1)}</td><td>{fmt(r.avg_wsd_min,1)}</td><td>{fmt(r.max_wsd_min,1)}</td><td>{fmt(r.avg_wosd_min,1)}</td><td>{fmt(r.max_wosd_min,1)}</td><td>{fmt(r.valid_wsd_count)}</td><td>{fmt(r.valid_wosd_count)}</td><td>{fmt(r.review_count)}</td><td>{fmt(r.excluded_count)}</td></tr>)}</tbody></table></div><div className="table-footer"><span>{fmt(ordered.length)} sites · Page {Math.min(page,pages)} of {pages}</span><div><button disabled={page<=1} onClick={()=>setPage(p=>p-1)}><ChevronLeft size={17}/></button><button disabled={page>=pages} onClick={()=>setPage(p=>p+1)}><ChevronRight size={17}/></button></div></div></section>}{(kpiDetail||customKpi)&&<div role="dialog" aria-modal="true" aria-label="KPI site review" style={{position:'fixed',inset:0,background:'rgba(11,29,41,.65)',zIndex:990,display:'flex',alignItems:'center',justifyContent:'center',padding:16}} onClick={closeKpi}>

 <div onClick={e=>e.stopPropagation()} style={{background:'#fff',borderRadius:16,width:'min(1440px,98vw)',maxHeight:'94vh',overflow:'auto',padding:22,color:'#183343',boxShadow:'0 18px 60px #0003'}}>

 <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:12,flexWrap:'wrap'}}>

 <div><div style={{fontSize:12,fontWeight:800,color:'#008f62'}}>SITE-LEVEL KPI REVIEW · {monthLabel}</div><h2 style={{margin:'7px 0'}}>{customKpi?customKpi.title:kpiDetail==='all'?'Total Sites Reviewed':kpiDetail==='satisfactory'?'Backup Satisfactory':kpiDetail==='low'?'Backup Below Standard':'Technical Review Required'} — {fmt(kpiRows.length)} sites</h2><p style={{color:'#627b8d',margin:0}}>Current dashboard filters apply. Select View Calculation to inspect source incidents.</p></div>

 <div style={{display:'flex',gap:9,alignItems:'center',flexWrap:'wrap'}}><input aria-label="Search KPI sites" value={kpiSearch} onChange={e=>setKpiSearch(e.target.value)} placeholder="Search site / grid / GTL…" style={{padding:11,border:'1px solid #cddde6',borderRadius:8,minWidth:220}}/><button className="outline" onClick={()=>exportCsv(kpiRows,`Central_BB_${reportMonth.slice(0,7)}_${kpiDetail}.csv`)}><Download size={15}/> Export CSV</button><button className="outline" onClick={closeKpi} aria-label="Close KPI review"><X size={18}/></button></div></div>

 {customKpi?.missingIds?.length? <div className="notice" style={{marginTop:12}}>Unmatched Site IDs (no calculation available): {customKpi.missingIds.join(', ')}</div>:null}<div style={{overflowX:'auto',marginTop:18}}><table style={{width:'100%',fontSize:12,borderCollapse:'collapse'}}><thead><tr>{['Site ID','Assessment','Sub-region','Grid','GTL','Revenue Class','DG Status','WSD Events','WOSD Events','Avg BB','Min BB','Max BB','Avg WSD','Max WSD','Avg WOSD','Max WOSD','Review','Excluded','Evidence'].map(h=><th key={h} style={{padding:10,textAlign:'left',whiteSpace:'nowrap',borderBottom:'2px solid #dbe5ea'}}>{h}</th>)}</tr></thead>

 <tbody>{kpiRows.slice((Math.min(kpiPage,kpiPageCount)-1)*25,Math.min(kpiPage,kpiPageCount)*25).map((r,i)=><tr key={r.site_id} style={{background:i%2?'#f4f8fb':'#fff'}}><td style={{padding:9,fontWeight:800}}>{r.site_id}</td><td style={{padding:9,whiteSpace:'nowrap',color:assessmentColor(assess(r)),fontWeight:700}}>{assess(r)}</td><td>{r.sub_region||'—'}</td><td>{r.grid||'—'}</td><td>{r.team_leader||'—'}</td><td>{r.revenue_category||'—'}</td><td>{r.dg_status||'—'}</td><td>{fmt(r.valid_wsd_count)}</td><td>{fmt(r.valid_wosd_count)}</td><td>{fmt(r.avg_bb_min,1)}</td><td>{fmt(r.min_bb_min,1)}</td><td>{fmt(r.max_bb_min,1)}</td><td>{fmt(r.avg_wsd_min,1)}</td><td>{fmt(r.max_wsd_min,1)}</td><td>{fmt(r.avg_wosd_min,1)}</td><td>{fmt(r.max_wosd_min,1)}</td><td>{fmt(r.review_count)}</td><td>{fmt(r.excluded_count)}</td><td><button className="outline" style={{whiteSpace:'nowrap',padding:'7px 10px'}} onClick={()=>{closeKpi();void openEvidence(r)}}><Eye size={14}/> View Calculation</button></td></tr>)}</tbody></table></div>

 <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:14}}><span>{fmt(kpiRows.length)} matched sites{customKpi?.missingIds?.length?` · ${customKpi.missingIds.length} unmatched`:''} · Page {Math.min(kpiPage,kpiPageCount)} / {kpiPageCount}</span><div style={{display:'flex',gap:8}}><button className="outline" disabled={kpiPage<=1} onClick={()=>setKpiPage(v=>v-1)}><ChevronLeft size={16}/></button><button className="outline" disabled={kpiPage>=kpiPageCount} onClick={()=>setKpiPage(v=>v+1)}><ChevronRight size={16}/></button></div></div></div></div>}

{selectedSite&&<div role="dialog" aria-modal="true" aria-label={`Site ${selectedSite.site_id} calculation evidence`} style={{position:'fixed',inset:0,background:'rgba(11,29,41,.65)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',padding:18}} onClick={()=>setSelectedSite(null)}><div onClick={e=>e.stopPropagation()} style={{background:'#fff',borderRadius:16,width:'min(1150px,98vw)',maxHeight:'92vh',overflow:'auto',padding:24,color:'#183343',boxShadow:'0 18px 60px #0003'}}><div style={{display:'flex',justifyContent:'space-between',gap:16,alignItems:'flex-start'}}><div><div style={{fontSize:12,fontWeight:800,color:'#088c63',letterSpacing:1}}>ALARM EVIDENCE / {monthLabel}</div><h2 style={{margin:'8px 0'}}>Site {selectedSite.site_id} — Backup Calculation</h2><div>{selectedSite.sub_region||'—'} · {selectedSite.grid||'—'} · {selectedSite.revenue_category||'—'} · {selectedSite.dg_status||'—'}</div></div><button className="outline" onClick={()=>setSelectedSite(null)} aria-label="Close calculation"><X size={18}/></button></div><div style={{margin:'18px 0',padding:14,borderRadius:10,background:assessmentBackground(assess(selectedSite)),color:assessmentColor(assess(selectedSite)),fontWeight:800}}>{assess(selectedSite)} · Assessment target {TARGET_MIN} minutes</div><div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(145px,1fr))',gap:10,marginBottom:16}}>{([['Average BB',selectedSite.avg_bb_min],['Maximum BB',selectedSite.max_bb_min],['Average WSD',selectedSite.avg_wsd_min],['Maximum WSD',selectedSite.max_wsd_min],['Average WOSD',selectedSite.avg_wosd_min],['Maximum WOSD',selectedSite.max_wosd_min]] as const).map(([name,val])=><div key={name} style={{background:'#f2f6f9',padding:12,borderRadius:10}}><div style={{fontSize:12,color:'#607788'}}>{name}</div><strong style={{fontSize:21}}>{fmt(val,1)}{val!==null?' min':''}</strong></div>)}</div><p style={{fontSize:13,color:'#546c7b'}}>Valid WSD events: {fmt(selectedSite.valid_wsd_count)} · Valid WOSD events: {fmt(selectedSite.valid_wosd_count)} · Excluded: {fmt(selectedSite.excluded_count)} · Review: {fmt(selectedSite.review_count)} · Average TOC: {fmt(selectedSite.avg_toc_hours,1)} h</p><div style={{background:'#f1f7f5',padding:14,borderRadius:10,fontSize:13,lineHeight:1.7,marginBottom:16}}><strong>Calculation methodology</strong><div>DG Operational = Yes → Rectifier Input Failure / Rectifier Input Failure 2. Other mapped DG statuses → Commercial Power Failure.</div><div><strong>WSD</strong> = Site Down occur time − Power Alarm occur time, where Site Down occurs before Power Alarm clear.</div><div><strong>WOSD</strong> = Power Alarm clear − occur, only if no qualifying Site Down during or in the post-clear review window.</div><div><strong>TOC</strong> = next Power Alarm start − previous Power Alarm clear.</div><div>Incidents above 500 minutes are excluded, not capped. Cross-midnight incidents remain valid. Under the current site rule, any validated WSD/WOSD observation ≥120 min classifies the site as satisfactory; otherwise a validated observation below 120 min classifies it as low.</div><div style={{color:'#8b5700'}}>Assessment is provisional when incident evidence is not imported or has not been independently reconciled. WOSD is demonstrated survival, not measured battery exhaustion.</div></div><div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:12,marginBottom:10}}><h3 style={{margin:0}}>Source alarm incidents ({fmt(incidentTotal)})</h3><button className="outline" onClick={()=>void loadEvidence(selectedSite.site_id,incidentPage)}><RefreshCw size={14}/> Refresh evidence</button></div>{incidentLoading?<div className="notice">Loading incident-level alarm evidence…</div>:incidentError?<div className="error">{incidentError}</div>:incidentTotal===0?<div className="notice">No incident-level alarm records are available for this site in Supabase. The site summary alone cannot prove the timestamp calculations. No evidence is available for this site and reporting month.</div>:<><div style={{overflowX:'auto'}}><table style={{width:'100%',fontSize:12,borderCollapse:'collapse'}}><thead><tr>{['Power alarm','PA occurred','PA cleared','Site Down','SD occurred','Type','Raw min','Valid min','TOC h','Decision / reason'].map(h=><th key={h} style={{padding:9,textAlign:'left',borderBottom:'1px solid #dbe4e9',whiteSpace:'nowrap'}}>{h}</th>)}</tr></thead><tbody>{incidents.map((i,k)=><tr key={i.id??i.incident_key??k} style={{background:k%2?'#f6f9fb':'#fff'}}><td style={{padding:8}}>{i.pa_title||'—'}</td><td style={{padding:8,whiteSpace:'nowrap'}}>{timestamp(i.pa_occur)}</td><td style={{padding:8,whiteSpace:'nowrap'}}>{timestamp(i.pa_clear)}</td><td style={{padding:8}}>{i.sd_title||'—'}</td><td style={{padding:8,whiteSpace:'nowrap'}}>{timestamp(i.sd_occur)}</td><td style={{padding:8}}>{i.bb_type||'—'}</td><td style={{padding:8}}>{fmt(i.raw_backup_min,1)}</td><td style={{padding:8,fontWeight:700}}>{fmt(i.validated_backup_min,1)}</td><td style={{padding:8}}>{fmt(i.toc_hours,1)}</td><td style={{padding:8}}>{i.validation_status}{i.exclusion_reason?` — ${i.exclusion_reason}`:''}</td></tr>)}</tbody></table></div><div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:12}}><span>Page {incidentPage} of {Math.max(1,Math.ceil(incidentTotal/INCIDENT_PAGE_SIZE))}</span><div style={{display:'flex',gap:8}}><button className="outline" disabled={incidentPage===1} onClick={()=>void loadEvidence(selectedSite.site_id,incidentPage-1)}><ChevronLeft size={16}/></button><button className="outline" disabled={incidentPage*INCIDENT_PAGE_SIZE>=incidentTotal} onClick={()=>void loadEvidence(selectedSite.site_id,incidentPage+1)}><ChevronRight size={16}/></button></div></div></>}</div></div>}

 <footer>Central BB Analytics · Source: selected reporting month site summary · 120-minute site assessment uses the best validated WSD/WOSD observation. WOSD indicates demonstrated outage survival, not measured battery capacity. Incident drill-down reads imported evidence from Supabase.</footer></main></div>}

export default App;
